# 📱 APEX — Mobile App Deployment Guide
### From Files on Your Computer → App on Your Phone

---

## ✅ WHAT YOU NEED BEFORE STARTING

- [ ] A computer (Windows, Mac, or Linux)
- [ ] An internet connection
- [ ] Your phone (Android or iPhone)
- [ ] A free GitHub account → https://github.com
- [ ] A free Netlify account → https://netlify.com

**Time needed:** About 30–45 minutes the first time.

---

## STEP 1 — INSTALL NODE.JS ON YOUR COMPUTER

Node.js lets your computer run the build tools that package your app.

1. Go to **https://nodejs.org**
2. Click the big green **"LTS"** button to download
3. Open the downloaded file and follow the installer (click Next → Next → Finish)
4. To confirm it worked:
   - On Windows: press `Win + R`, type `cmd`, press Enter
   - On Mac: open the **Terminal** app
   - Type this and press Enter:
     ```
     node --version
     ```
   - You should see something like `v20.11.0` — that means it worked ✅

---

## STEP 2 — SET UP YOUR PROJECT FILES

1. **Download the `apex-app` folder** from this conversation (the zip file Claude provided)
2. **Unzip it** somewhere easy to find — like your Desktop
3. Open your Terminal / Command Prompt
4. **Navigate to the project folder:**
   ```
   cd Desktop/apex-app
   ```
   *(If you saved it somewhere else, adjust the path)*
5. **Install the project dependencies:**
   ```
   npm install
   ```
   This downloads React, Vite, and the PWA plugin. Wait for it to finish (1–2 min).

6. **Test the app locally:**
   ```
   npm run dev
   ```
   Open your browser and go to **http://localhost:5173** — you should see APEX running! 🎉

   Press `Ctrl + C` to stop the dev server when you're done.

---

## STEP 3 — BUILD THE APP

This packages everything into a production-ready folder called `dist/`:

```
npm run build
```

You'll see output like `✓ built in 8.23s` — that means it worked ✅

---

## STEP 4 — PUSH TO GITHUB

GitHub stores your code online so Netlify can access it.

### 4a. Create a GitHub account
Go to **https://github.com** and sign up (it's free).

### 4b. Create a new repository
1. Click the **"+"** icon in the top right → **"New repository"**
2. Name it: `apex-app`
3. Set it to **Public**
4. Click **"Create repository"**

### 4c. Upload your files to GitHub
GitHub will show you a page with instructions. Choose the **"upload files"** link:

1. Click **"uploading an existing file"** link on that page
2. Drag your entire `apex-app` folder contents into the upload box
   *(Do NOT include the `node_modules` folder — it's huge and not needed)*
3. Scroll down, write a commit message like `"Initial upload"`
4. Click **"Commit changes"**

> 💡 **Alternative (if you're comfortable with Terminal):**
> ```
> git init
> git add .
> git commit -m "Initial commit"
> git remote add origin https://github.com/YOUR_USERNAME/apex-app.git
> git push -u origin main
> ```

---

## STEP 5 — DEPLOY TO NETLIFY

1. Go to **https://netlify.com** and sign in (you can sign in with your GitHub account)
2. Click **"Add new site"** → **"Import an existing project"**
3. Click **"GitHub"** and authorize Netlify to access your repos
4. Find and click on **`apex-app`**
5. Netlify will auto-detect the settings from `netlify.toml`. Just confirm:
   - Build command: `npm run build`
   - Publish directory: `dist`
6. Click **"Deploy site"**
7. Wait about 1–2 minutes. Netlify gives you a live URL like:
   ```
   https://amazing-tesla-4f8b12.netlify.app
   ```
   **That's your live APEX app!** Open it in your phone browser to test. ✅

### Optional: Give it a better URL
1. In Netlify dashboard → **"Domain settings"**
2. Click **"Options"** → **"Edit site name"**
3. Change it to something like `apex-training` → your URL becomes `https://apex-training.netlify.app`

---

## STEP 6 — INSTALL IT ON YOUR PHONE 📱

### 🤖 On Android (Recommended — works perfectly)

1. Open **Chrome** on your Android phone
2. Go to your Netlify URL (e.g., `https://apex-training.netlify.app`)
3. Wait for the page to fully load
4. Tap the **three dots menu** (⋮) in the top right
5. Tap **"Add to Home screen"**
6. Tap **"Add"** on the popup
7. Find the APEX icon on your home screen — tap it!
8. It opens **full screen, no browser bar**, just like a real app ✅

> 🎯 Chrome may also show a banner at the bottom saying **"Add APEX to Home Screen"** — just tap that!

### 🍎 On iPhone

1. Open **Safari** (must be Safari, not Chrome, on iPhone)
2. Go to your Netlify URL
3. Wait for the page to fully load
4. Tap the **Share button** (the box with an arrow pointing up) at the bottom
5. Scroll down and tap **"Add to Home Screen"**
6. Tap **"Add"** in the top right
7. Find APEX on your home screen — tap it to open full screen ✅

---

## STEP 7 — PACKAGE AS REAL APK WITH PWABUILDER (Optional)

Want a proper `.apk` file you can send to friends to install directly?

1. Go to **https://www.pwabuilder.com**
2. Paste your Netlify URL into the input box
3. Click **"Start"**
4. PWABuilder will analyze your app and give it a score
5. Click **"Package For Stores"**
6. Choose **Android** → **"Download Package"**
7. You'll get a `.apk` file
8. Transfer it to your Android phone and open it to install

> ⚠️ To install an APK on Android, you may need to enable "Install from unknown sources" in your phone settings → Security.

---

## 🔄 HOW TO UPDATE YOUR APP LATER

When you make changes to the code:

1. Make your edits in `src/App.jsx`
2. Run `npm run build` again
3. Push the updated files to GitHub
4. Netlify **automatically redeploys** within 1–2 minutes
5. The app on your phone updates automatically next time you open it ✅

---

## 🆘 TROUBLESHOOTING

| Problem | Solution |
|---|---|
| `npm: command not found` | Reinstall Node.js from nodejs.org |
| Build fails with an error | Share the error message — likely a missing dependency |
| Netlify shows "Page Not Found" | Check that `netlify.toml` is in your project root |
| App not showing on iPhone home screen | Must use Safari (not Chrome) on iPhone |
| APK won't install on Android | Enable "Install unknown apps" in Android Settings → Security |
| App doesn't work offline | Open it once with internet, then it caches for offline use |

---

## 📁 YOUR PROJECT FILE STRUCTURE

```
apex-app/
├── src/
│   ├── App.jsx          ← Your APEX app code (the main file)
│   └── main.jsx         ← React entry point
├── public/
│   ├── icon-192.png     ← App icon (Android)
│   ├── icon-512.png     ← App icon (large)
│   └── apple-touch-icon.png  ← App icon (iPhone)
├── index.html           ← HTML shell
├── vite.config.js       ← Build config + PWA setup
├── package.json         ← Project dependencies
├── netlify.toml         ← Netlify deployment settings
└── .gitignore           ← Files to exclude from GitHub
```

---

**Built with React + Vite + vite-plugin-pwa**
**Deployed on Netlify | Packaged via PWABuilder**
